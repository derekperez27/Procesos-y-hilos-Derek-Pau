package cFilPrincipal;

import cFil . cFil;
import java . util . Scanner;

public class cFilPrincipal {

  public static void main (String [] pArguments) {

    final int MAX = 20;
    int vNumFills;

    System . out . println ("Fil principal iniciat.");

    Scanner vScanner = new Scanner (System . in);
    System . out . print ("Cuantos processos quieres iniciar? 0-20: ");
    vNumFills = vScanner . nextInt ();
    vScanner . close ();

    if (vNumFills < 0) {
      vNumFills = 0;
    }

    if (vNumFills > MAX) {
      System . out . println ("El nombre de fills supera el màxim permès (" + MAX + "). S'utilitzarà " + MAX + ".");
      vNumFills = MAX;
    }

    Thread [] vFils = new Thread [vNumFills];

    for (int i = 0; i < vNumFills; i ++) {
      cFil vObjecteFil = new cFil ("#" + (i + 1));
      int vTemporitzacio = 100 + (i * 100);
      vObjecteFil . sTemporitzacio (vTemporitzacio);
      
      vFils [i] = new Thread (vObjecteFil);
      vFils [i] . start ();
      
      System . out . println ("Fil secundari #" + (i + 1) + " iniciat amb temporització " + vTemporitzacio + "ms.");
    }

    System . out . println ("Iniciant execució procés principal");

    try {

      for (int vComptador = 0; vComptador < 10; vComptador ++) {

        Thread . sleep (500);

        System . out . println ("Despertant aturada " + vComptador + " procès principal");

      }

      for (int i = 0; i < vNumFills; i ++) {
        vFils [i] . join ();
      }

    }

    catch (InterruptedException pExcepcio) {

      System . out . println ("Interrompent execució procès principal");

    }

    System . out . println ("Acabant execució procès principal");

  }

}
